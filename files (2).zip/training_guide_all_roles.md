# Virtual Expediter™ Training Guide

---

## Section 1: General Onboarding

**Step 1:** Log in to your device (KDS, handheld, or manager dashboard).  
**Step 2:** Pair your Bluetooth earpiece; test audio before each shift.  
**Step 3:** Review your station dashboard for new tickets and alerts.

---

## Section 2: Expo Lead

- **Receive new tickets:** See ticket tiles—look for allergy badges!
- **Voice Acknowledgment:** Say “Acknowledged” or tap the confirm button.
- **Escalation:** If no ack in 90s, system escalates to manager for override.
- **Announce orders:** Use headset or visual cues.

---

## Section 3: Grill / Fry / Salad

- **Monitor station queue:** Prep only after Expo or station lead acknowledgment.
- **Allergy/Special Handling:** Red border and icon means check details!
- **Mark items ready:** Tap or voice command.
- **Handoff:** Confirm runner/courier pick-up in app.

---

## Section 4: Runner/Courier

- **Delivery timeline:** Watch for “ready” tickets in delivery queue.
- **Pickup:** Confirm in app when ticket is picked up.
- **Troubleshooting:** Use visual fallback if headset fails.

---

## Section 5: Manager

- **Dashboard:** Monitor live KPIs—cycle time, acks, ready before courier.
- **Training:** Track staff proficiency, schedule practice in Training Mode.
- **Compliance:** Review audit logs; enforce data retention policies.

---

## Section 6: Training Mode

- **Select “Training” on login.**
- **Practice call-and-response:** System simulates tickets, tracks proficiency.
- **Voice recognition:** Try different acknowledgment phrases.
- **Monthly cap:** 10 hours/employee; overages alert manager.

---

## Section 7: Visual Flowchart

```mermaid
flowchart TD
    A[New Ticket] --> B{Expo Ack?}
    B -- Yes --> C[Prep Begins]
    B -- No, 90s --> D[Escalate to Manager]
    C --> E[Station Ready]
    E --> F[Runner Pickup]
    F --> G[Served/Delivered]
    D --> C
```