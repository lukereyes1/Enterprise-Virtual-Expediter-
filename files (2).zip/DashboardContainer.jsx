import React from "react";

export default function DashboardContainer({ kpis }) {
  // kpis = { cycleTime, ackRate, readyPct, laborSavings }
  return (
    <div style={{ padding: "20px", background: "#fafafa" }}>
      <h2>Manager KPIs</h2>
      <div style={{ display: "flex", gap: "40px" }}>
        <div>
          <h3>Cycle Time</h3>
          <div style={{ fontSize: 32, color: "#2196F3" }}>
            {kpis.cycleTime} min
          </div>
        </div>
        <div>
          <h3>Acknowledgment Rate</h3>
          <div style={{ fontSize: 32, color: "#32CD32" }}>
            {kpis.ackRate}%
          </div>
        </div>
        <div>
          <h3>Ready Before Courier</h3>
          <div style={{ fontSize: 32, color: "#FFD700" }}>
            {kpis.readyPct}%
          </div>
        </div>
        <div>
          <h3>Labor Savings</h3>
          <div style={{ fontSize: 32, color: "#FF9800" }}>
            ${kpis.laborSavings}
          </div>
        </div>
      </div>
    </div>
  );
}