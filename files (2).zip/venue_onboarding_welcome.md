# Virtual Expediter™ Venue Onboarding Packet

---

## Pre-Launch Checklist

- [ ] POS credentials (Square, Clover)
- [ ] Delivery platform access (Deliverect)
- [ ] Staff roster uploaded
- [ ] Bluetooth earpieces distributed/tested
- [ ] Venue network test completed

---

## Staff Welcome

**Welcome to the Virtual Expediter Pilot!**

- You’ll see new ticket tiles and alerts on your device
- Wireless earpiece lets you acknowledge by voice—just say “Acknowledged”
- Use Training Mode to practice with simulated tickets
- Managers will monitor KPIs and help you improve

**Support:** For help, tap “Support” or call [venue helpdesk]

---

## Cheat Sheet (Expo Example)

- **New ticket:** Announce and acknowledge within 90s
- **Allergy badge:** Confirm guest info before prep
- **Escalate:** Tap “Escalate” if delayed
- **Training:** Log hours monthly, check dashboard for progress

---

## Visual Flow: Onboarding

```mermaid
graph TD
    A[Staff Trained] --> B[Device Setup]
    B --> C[Live Pilot Launch]
    C --> D[KPIs Monitored]
    D --> E[Feedback/Iterate]
```