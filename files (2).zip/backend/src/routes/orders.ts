import { Router } from "express";

const router = Router();

router.get("/", (req, res) => {
  // Return all tickets (role-filtered, privacy redacted)
  res.json([
    { id: 1, items: ["Burger"], station: "Grill", status: "new", eta: 11, allergy: "nuts" },
    // ...etc
  ]);
});

router.post("/", (req, res) => {
  // Intake POS/delivery ticket, redact PII/allergy if privacy mode
  // Save to DB, emit to channel router
  res.status(201).json({ success: true, ticket: req.body });
});

export const orderRoutes = router;