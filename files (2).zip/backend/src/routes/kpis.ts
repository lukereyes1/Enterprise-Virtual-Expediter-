import { Router } from "express";

const router = Router();

router.get("/", (req, res) => {
  // Return KPIs for dashboard
  res.json({
    cycleTime: 27,
    ackRate: 96,
    readyPct: 92,
    laborSavings: 52000,
    refundSavings: 11600,
    deliveryOpt: 9200
  });
});

export const kpiRoutes = router;