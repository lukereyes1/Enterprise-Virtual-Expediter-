import { Router } from "express";

const router = Router();

router.post("/start-room", (req, res) => {
  // Initiate LiveKit/WebRTC audio room
  res.json({ success: true, roomId: "expo-room-123" });
});

router.post("/stt", (req, res) => {
  // Speech-to-text stub (replace with real service)
  res.json({ text: "Acknowledged. Table 12, nuts allergy." });
});

router.post("/tts", (req, res) => {
  // Text-to-speech stub (replace with real service)
  res.json({ audioUrl: "/audio/tts-sample.mp3" });
});

export const voiceRoutes = router;