import { Router } from "express";
import { agenticDashboardAI } from "../agentic/aiEngine";
import { enforcePrivacy } from "../agentic/securityAI";
import { handleVoiceInput } from "../agentic/voiceAI";

const router = Router();

router.post("/dashboard", async (req, res) => {
  try {
    const safeKpiData = await enforcePrivacy(req.body.userRole, req.body.location, req.body.kpiData);
    const agenticResult = await agenticDashboardAI(safeKpiData, req.body.userRole);
    res.json(agenticResult);
  } catch (err) {
    res.status(403).json({ error: err.message });
  }
});

// Voice intent endpoint
router.post("/voice", async (req, res) => {
  try {
    const userRole = req.headers["x-user-role"] as string;
    const buffer = Buffer.from(req.body); // works if body is raw buffer
    const result = await handleVoiceInput(buffer, userRole);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

export const agenticRoutes = router;