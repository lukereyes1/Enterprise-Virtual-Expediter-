import { Router } from "express";

const router = Router();

router.post("/set-mode", (req, res) => {
  // Set privacy mode for location (closed, audit, region lock)
  res.json({ success: true, mode: req.body.mode });
});

router.get("/status", (req, res) => {
  // Return current privacy/compliance status
  res.json({ mode: "closed", region: "EU", retentionDays: 30 });
});

export const privacyRoutes = router;