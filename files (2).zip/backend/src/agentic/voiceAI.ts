import { classifyIntent, transcribeSpeech } from "./aiLib";

export async function handleVoiceInput(audioBuffer: Buffer, userRole: string) {
  const transcript = await transcribeSpeech(audioBuffer);
  const intent = classifyIntent(transcript, userRole);

  // Here, you could trigger actions on backend (e.g., mark ticket ready, acknowledge, escalate, etc.)
  // For now, just return for dashboard UI to handle
  return { transcript, intent };
}