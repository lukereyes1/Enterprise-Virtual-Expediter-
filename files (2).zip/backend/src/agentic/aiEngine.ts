import {
  analyzeKPI,
  detectAnomaly,
  recommendAction,
  azureAnalyzeKPI,
  customModelKPI,
} from "./aiLib";

export async function agenticDashboardAI(kpiData: any, userRole: string) {
  let kpiAnalysis, anomalies, recommendations;
  switch (process.env.AGENTIC_AI_PROVIDER) {
    case "openai":
      kpiAnalysis = await analyzeKPI(kpiData);
      anomalies = await detectAnomaly(kpiData);
      recommendations = await recommendAction(kpiData, userRole);
      break;
    case "azure":
      kpiAnalysis = await azureAnalyzeKPI(kpiData);
      anomalies = ["Azure anomaly detection not implemented"];
      recommendations = ["Azure recommendations not implemented"];
      break;
    case "custom":
      kpiAnalysis = await customModelKPI(kpiData);
      anomalies = ["Custom anomaly detection not implemented"];
      recommendations = ["Custom recommendations not implemented"];
      break;
    default:
      kpiAnalysis = "No AI provider configured";
      anomalies = [];
      recommendations = [];
  }

  return {
    status: "ok",
    kpiAnalysis,
    anomalies,
    recommendations,
  };
}