import { OpenAI } from "openai";
import axios from "axios";

// --- OpenAI Integration ---
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export async function transcribeSpeech(audioBuffer: Buffer) {
  // Replace with real OpenAI Whisper endpoint / Azure STT
  // For demo, fake transcript
  return "Order ready for pickup";
}

export function classifyIntent(transcript: string, userRole: string) {
  // Simple rules-based intent extraction
  transcript = transcript.toLowerCase();
  if (transcript.includes("ready")) return "markReady";
  if (transcript.includes("acknowledge")) return "acknowledge";
  if (transcript.includes("escalate")) return "escalate";
  return "unknown";
}