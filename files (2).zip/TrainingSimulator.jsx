import React, { useState } from "react";

export default function TrainingSimulator({ tickets }) {
  const [current, setCurrent] = useState(0);
  const [response, setResponse] = useState("");
  const ticket = tickets[current];

  function handleNext() {
    setResponse("");
    setCurrent((prev) => (prev + 1) % tickets.length);
  }

  return (
    <div style={{ padding: "20px", background: "#f8e4b2", borderRadius: "12px" }}>
      <h2>Training Mode</h2>
      <div>
        <b>Simulated Ticket:</b> {ticket.items.join(", ")} ({ticket.station})
        {ticket.allergy && (
          <span style={{ color: "red", marginLeft: 10 }}>
            Allergy: {ticket.allergy}
          </span>
        )}
      </div>
      <input
        type="text"
        value={response}
        placeholder="Type your acknowledgment..."
        onChange={e => setResponse(e.target.value)}
        style={{ marginTop: "12px", padding: "8px", width: "60%" }}
      />
      <button onClick={handleNext} style={{ marginLeft: "10px" }}>
        Next
      </button>
    </div>
  );
}