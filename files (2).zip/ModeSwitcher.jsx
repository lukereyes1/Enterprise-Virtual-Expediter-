import React from "react";

export default function ModeSwitcher({ mode, setMode }) {
  const modes = [
    "fastCasual",
    "fineDining",
    "chain",
    "catering"
  ];
  return (
    <div style={{ display: "flex", gap: "10px", marginBottom: "20px" }}>
      {modes.map(m => (
        <button
          key={m}
          style={{
            background: mode === m ? "#32CD32" : "#eee",
            color: "#333",
            borderRadius: "6px",
            padding: "8px 16px",
            fontWeight: "bold"
          }}
          onClick={() => setMode(m)}
        >
          {m.replace(/([A-Z])/g, " $1").replace(/^./, str => str.toUpperCase())}
        </button>
      ))}
    </div>
  );
}