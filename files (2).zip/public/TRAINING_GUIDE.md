# Virtual Expediter™ Training Guide

## Expo Lead
1. Log in and pair headset.
2. Announce ticket within 90s (voice/tap).
3. Watch for allergy badges (red).
4. Escalate if not acknowledged in time.
5. Track KPIs in dashboard.

## Station Lead (Grill/Fry/Salad)
1. Prep only after Expo/lead acknowledgment.
2. Ready items via tap or voice.
3. Handoff to runner/courier.
4. Use visual mode if headset fails.

## Runner/Courier
1. Monitor delivery queue.
2. Confirm pickup (tap/voice).
3. Escalate delays via app.

## Manager
1. Track KPIs: cycle time, acks, ready/courier, errors.
2. Schedule training sessions.
3. Monitor audit logs and compliance.

## Training Mode
- Practice call-and-response.
- Monthly cap: 10hr/employee.
- System escalates on missed acks.

## Quick Reference
- Announce ticket within 90s.
- Red badge = allergy/special handling.
- Use voice or tap for acknowledgment.
- Escalate if unable to acknowledge.
- Track training hours via dashboard.