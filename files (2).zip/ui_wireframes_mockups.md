# Virtual Expediter™ UI Wireframes & Mockups

---

## Fast Casual Mode

![Fast Casual UI](https://dummyimage.com/600x350/c2f0c2/333333&text=Fast+Casual+UI)

- Compact ticket tiles
- Badge for allergy/modifiers
- ETA display per ticket
- Mode switcher (top right)

---

## Fine Dining Mode

![Fine Dining UI](https://dummyimage.com/600x350/eaeaea/333333&text=Fine+Dining+UI)

- Timeline for multi-course tickets
- Full item names, allergy warnings (red highlight)
- Table/guest details

---

## Chain Mode

![Chain Mode UI](https://dummyimage.com/600x350/bee3f2/333333&text=Chain+UI)

- Brand logo, standardized tiles
- KPI banner (cycle time, error rate)
- Station filter

---

## Catering Mode

![Catering UI](https://dummyimage.com/600x350/f8e4b2/333333&text=Catering+UI)

- Batch ticket view (multiple orders at once)
- Courier scheduling panel
- Staffing forecast meter

---

## Mode Switcher

```mermaid
graph LR
    FastCasual -->|Click| FineDining
    FineDining -->|Click| Chain
    Chain -->|Click| Catering
    Catering -->|Click| FastCasual
```