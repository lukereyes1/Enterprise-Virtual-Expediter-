import React from "react";

export default function TicketTile({
  ticket,
  onAcknowledge,
  onEscalate,
  onReady,
  mode = "fastCasual",
}) {
  const statusColors = {
    new: "#FFD700",
    pending_ack: "#FFA500",
    in_prep: "#87CEEB",
    ready: "#32CD32",
    served: "#A9A9A9",
    escalated: "#FF4500",
    cancelled: "#B22222",
  };

  return (
    <div
      style={{
        border: `3px solid ${statusColors[ticket.status]}`,
        borderRadius: "10px",
        padding: "16px",
        margin: "10px",
        background: "#fff",
        minWidth: "220px",
        boxShadow: "0 2px 7px #eee",
      }}
    >
      <div style={{ fontWeight: "bold", fontSize: 20 }}>
        {ticket.items.join(", ")}
      </div>
      <div>
        <span>
          {ticket.station} | ETA: <b>{ticket.eta} min</b>
        </span>
        {ticket.allergy && (
          <span style={{ color: "red", marginLeft: 10, fontWeight: "bold" }}>
            🔔 Allergy: {ticket.allergy}
          </span>
        )}
      </div>
      <div style={{ marginTop: 10 }}>
        <button onClick={() => onAcknowledge(ticket.id)}>Acknowledge</button>
        <button onClick={() => onEscalate(ticket.id)} style={{ marginLeft: 5 }}>
          Escalate
        </button>
        <button onClick={() => onReady(ticket.id)} style={{ marginLeft: 5 }}>
          Ready
        </button>
      </div>
    </div>
  );
}