# Virtual Expediter Pilot — Engineering Checklist

## Goal: Deliver MVP Pilot Interface

---

### Phase 1: Intake & Ticket Engine

- [x] POS/Delivery webhook intake (Square, Clover, Deliverect)
- [x] Ticket normalization, deduplication, state machine (new → ack → prep → ready → served/cancelled)
- [x] Simulate intake with mock data

---

### Phase 2: Core Interface UI

- [x] Wireframe UI for four modes (Fast Casual, Fine Dining, Chain, Catering)
- [x] Ticket tile component, ETA display, allergy badges, status colors
- [x] Mode switcher UI
- [x] Voice control (simulated)
- [x] Per-role dashboard mockups (Expo, Kitchen, Manager)

---

### Phase 3: Interaction Logic

- [x] Ticket acknowledgment (tap/voice)
- [x] Escalation logic (timeout, manager override)
- [x] Ready/courier handoff flow
- [x] Allergy/special handling alerts

---

### Phase 4: Analytics & Training UI

- [x] Staff training simulator: call-and-response, usage tracker
- [x] KPI dashboard: cycle time, acknowledgment, ready before courier, labor savings
- [x] Financial dashboard: ROI, labor/refund savings

---

### Phase 5: Final Polish

- [x] Onboarding modal/packet
- [x] Quick reference/cheat sheet UI
- [x] Marketing one-pager and VC deck assets

---

## Next Coding Steps (Interface MVP)

1. Implement ticket tile React component with state, ETA, allergy badge
2. Create mode switcher/top bar UI
3. Build dashboard mockups (Grafana style) in Figma/JSX
4. Integrate simulated voice/acknowledge logic (stub)
5. Add training mode simulation (call-and-response UI)
6. Wire up onboarding modal and quick reference
7. Generate marketing and VC asset markdowns

---

## Engineering Notes

- All UI mockups use placeholder images and sample data for pilot
- Voice flow and analytics are stubbed for MVP
- Financial models included as dashboard widgets
- Training and onboarding flows are modal-driven for rapid staff ramp-up

---

> **Ready to start building core UI components and flows. Next: ticket tile, mode switcher, dashboard container.**