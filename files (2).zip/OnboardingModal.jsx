import React from "react";

export default function OnboardingModal({ onClose }) {
  return (
    <div style={{
      position: "fixed", top: 0, left: 0, width: "100vw", height: "100vh",
      background: "rgba(0,0,0,0.2)", display: "flex", alignItems: "center",
      justifyContent: "center", zIndex: 1000
    }}>
      <div style={{
        background: "#fff", padding: "32px", borderRadius: "16px",
        width: "420px", boxShadow: "0 2px 15px #aaa"
      }}>
        <h2>Welcome to Virtual Expediter!</h2>
        <ul style={{ fontSize: "16px" }}>
          <li>Log in and pair your headset.</li>
          <li>Announce new tickets within 90s.</li>
          <li>Watch for allergy badges (red).</li>
          <li>Acknowledge via voice or tap.</li>
          <li>Escalate if unable to acknowledge.</li>
          <li>Track training hours in dashboard.</li>
        </ul>
        <button onClick={onClose}
          style={{ marginTop: "16px", padding: "10px 24px", borderRadius: "8px", background: "#32CD32", color: "#fff", fontWeight: "bold" }}>
          Got it!
        </button>
      </div>
    </div>
  );
}