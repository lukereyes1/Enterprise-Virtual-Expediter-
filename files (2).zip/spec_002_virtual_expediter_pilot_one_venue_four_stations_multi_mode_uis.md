# SPEC-002-Enterprise Virtual Expediter Pilot

## Background

Large restaurants and catering operations often face problems like misplaced tickets, slow hand‑offs, and poor coordination between staff. This pilot project introduces a real‑time virtual expediter that connects to POS systems (Square, Clover) and delivery platforms (Deliverect for Uber Eats and DoorDash). The system supports hands‑free communication via wireless earpieces and gives managers analytics for speed and accuracy. The pilot will run in one venue with four stations (Grill, Fry, Salad, Expo) and provide four tailored interface modes (Fast Casual, Fine Dining, Chain, Catering) plus a dedicated Training Mode.

## Requirements

### Must‑have (M)

1. POS connectors for Square and Clover with webhook ingestion, OAuth security, deduplication, and replay handling.
2. Delivery aggregation using Deliverect for Uber Eats and DoorDash, including order status updates and retries.
3. Ticket Engine with lifecycle states (`new → pending_ack → in_prep → ready → served/cancelled`) and required station‑lead acknowledgment before prep.
4. Voice interface using LiveKit SFU, Bluetooth headset routing (iOS/Android), real‑time speech‑to‑text (STT) and text‑to‑speech (TTS), with quiet hours (22:00–07:00).
5. Channel Router secured with JWT + ABAC, per‑location encryption, and per‑message audit logging.
6. Training Mode with simulated orders and couriers, call‑and‑response voice training, and a 10‑hour monthly cap per employee with overage billing.
7. Privacy and compliance: PCI minimization, GDPR alignment, 30‑day data retention in standard mode and 7‑day retention in strict mode.
8. Data residency set by the account owner with region‑locked storage and compute.

### Should‑have (S)

1. Queue‑aware ETA predictions using rolling medians and time‑of‑day adjustments.
2. Role‑specific dashboards in Grafana backed by ClickHouse and dbt.
3. Enterprise administration features for multi‑location hierarchies and policy controls.

### Could‑have (C)

1. Import of reservation details for allergies or special occasions.
2. PSTN telephony fallback for managers.
3. Computer vision to track station readiness.

### Won’t‑have for pilot (W)

1. Delivery integrations outside of Deliverect (Uber Eats, DoorDash).
2. Enterprise SSO for dashboards (local authentication is acceptable for the pilot).

## Method

### Architecture Overview

```plantuml
@startuml
skinparam componentStyle rectangle
actor Expo
actor Station
actor Runner
package "Venue" {
  [KDS/Handheld Apps]
  [Earpiece Mobile Apps]
}
package "Core Cloud" {
  [POS Intake Service]
  [Aggregator Intake]
  [Ticket Engine]
  [Channel Router]
  [Voice Agent]
  [Admin API]
  [Analytics (ClickHouse+dbt)]
  [Event Bus]
}
package Vendors {
  [Square Webhooks]
  [Clover Webhooks]
  [Deliverect Webhooks]
  [LiveKit SFU]
  [STT/TTS Provider]
  [Square Billing]
}
Square Webhooks --> POS Intake Service
Clover Webhooks --> POS Intake Service
Deliverect Webhooks --> Aggregator Intake
POS Intake Service --> Event Bus
Aggregator Intake --> Event Bus
Event Bus --> Ticket Engine
Ticket Engine --> Channel Router
Channel Router --> [KDS/Handheld Apps]
Channel Router --> [Earpiece Mobile Apps]
Voice Agent --> [LiveKit SFU]
Voice Agent --> [STT/TTS Provider]
Admin API --> Ticket Engine
Admin API --> Channel Router
Ticket Engine --> Analytics (ClickHouse+dbt)
Admin API --> [Square Billing]
@enduml
```

### Ticket State Machine

```plantuml
@startuml
[*] --> new
new --> pending_ack
pending_ack --> in_prep : station_lead_ack (voice/manual)
pending_ack --> escalated : timeout(90s)
escalated --> in_prep : manager_override
in_prep --> ready : items_complete
ready --> served : runner_handoff | courier_pickup
[*] --> cancelled : cancel
@enduml
```

### Event Mapping

- **Square:** `payments.updated` and `orders.updated` events → Retrieve order → Normalize → `ticket.upsert`.
- **Clover:** `order.updated` webhook → REST fetch → Normalize → `ticket.upsert`.
- **Deliverect (Uber Eats, DoorDash):** `order.notification` and delivery events → Normalize → `ticket.upsert` + `delivery.job.upsert`.

### Voice Policies (Defaults)

- Quiet hours: 22:00–07:00 local time.
- Item names: full by default; abbreviations optional.
- Acknowledgment: required; accepted keywords: “acknowledged”, “got it”.
- Routing: Expo room uses open‑mic with VAD; stations use push‑to‑talk at peak times.
- Fallback: visual banners and haptics if TTS/STT unavailable.

### UI Modes

- **Fast Casual:** compact tiles, high throughput metrics, optional abbreviation.
- **Fine Dining:** course timelines, full names, clear allergy warnings.
- **Chain:** standardized templates, brand assets, consistent KPIs.
- **Catering:** batch tickets, staffing forecasts, courier scheduling.

### Database Schemas

(SQL schema unchanged — see original for details.)

### ETA Algorithm

- For item *i* at station *s*:
  - `base = max(median_30d(i,s), p50_by_hour(i,s))`
  - `queue_adj = remaining_work(s) / parallelism(s)`
  - `eta_i = now + base + queue_adj`
- Course ETA = max(item ETAs within the course).
- Ticket ETA = max(course ETAs).

### Security & Privacy

- Deny‑by‑default JWT + ABAC access.
- Per‑location encryption keys rotated every 30 days.
- Privacy modes:
  - **Standard:** 30‑day retention, logs enabled, PII redacted.
  - **Strict:** 7‑day retention, minimal logs, no screenshots.
- Data residency chosen by account owner; cross‑region decryption blocked.

### Billing

- Square Subscriptions for base platform and per‑user UI mode add‑ons.
- Square Invoices for overages: training voice time beyond 10 hours/employee/month.
- Preferred: cards on file; fallback: emailed invoice.

### Training Mode

- Full platform available with `is_training=true` isolation.
- Voice call‑and‑response training with escalation if no ack in 90s.
- Usage cap: 10 hours per employee/month. Overage logged and invoiced.

## Implementation

1. **POS & Aggregator Intake:** Register webhooks (Square, Clover, Deliverect). Validate signatures, deduplicate, and hydrate orders.
2. **Ticket Engine:** Enforce pending\_ack before prep. Apply station routing rules and compute ETAs.
3. **Voice Stack:** Deploy LiveKit, integrate STT/TTS, implement VAD and push‑to‑talk, and handle Bluetooth headset routing.
4. **Channel Router:** Enforce JWT+ABAC, per‑message encryption, and audit trails. Provide visual fallback if voice fails.
5. **UI Shells:** React implementations for four modes. Per‑user mode switch linked to billing.
6. **Training Simulator:** Generate test orders and courier events. Run call‑and‑response sessions with ack and escalation. Track usage.
7. **Analytics:** Stream events to ClickHouse. Apply dbt transforms for KPIs. Create Grafana dashboards by role.
8. **Billing:** Define Square catalog plans and subscriptions. Generate invoices for overages. Handle webhooks.
9. **Privacy & Residency:** Apply account policies for region and retention. Enforce at all layers.
10. **Reliability & QA:** Device WAL and server retries. Track SLOs. Add monitoring, load, chaos, and offline testing. Prepare runbooks.

## Milestones

- **M0 Sandbox Connectivity:** Webhooks from Square/Clover/Deliverect received and stored.
- **M1 Ticket Engine MVP:** Sequencing, routing, allergy checks, pending\_ack enforcement.
- **M2 Voice Rooms + Earpieces:** Low‑latency audio on iOS/Android; ack capture verified.
- **M3 KDS/Handheld UIs:** Four modes delivered with badges, ack, ETA tiles, and delivery timeline.
- **M4 Analytics/ETAs:** KPIs online; ETA error P50 ≤ 90s for hot line.
- **M5 Billing/Policies:** Square subscriptions and overage invoices active; residency/retention settable.
- **M6 Training Go‑Live:** Voice training complete; ≥90% staff show proficiency.
- **M7 Pilot Review:** Compare pre‑ vs post‑pilot cycle times and on‑time course fire rate.

## Gathering Results

- **Operational KPIs:** expo call‑to‑ack latency, ticket cycle times, ready‑before‑courier‑ETA %, holds >8 min, cancellation causes.
- **Voice/STT:** STT accuracy, ack recognition latency, device routing success.
- **Reliability:** webhook latency, fanout success, offline WAL backlog.
- **Training:** completion rates, number of attempts per ack, time‑on‑task vs proficiency.
- **Success Criteria:** ≥15% reduction in cycle time, ≥95% acks within 90s, ≥90% tickets ready before courier ETA.

## Need Professional Help?

Contact [sammuti.com](https://sammuti.com)