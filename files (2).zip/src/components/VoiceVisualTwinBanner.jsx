import React, { useEffect, useState } from "react";
import { Fade, Box } from "@mui/material";

export default function VoiceVisualTwinBanner({ message }) {
  const [visible, setVisible] = useState(!!message);

  useEffect(() => {
    if (message) {
      setVisible(true);
      const timeout = setTimeout(() => setVisible(false), 3000);
      return () => clearTimeout(timeout);
    }
  }, [message]);

  return (
    <Fade in={visible}>
      <Box sx={{
        position: "fixed",
        bottom: 30,
        left: "50%",
        transform: "translateX(-50%)",
        zIndex: 2500,
        background: "#2193b0",
        color: "#fff",
        px: 4, py: 2,
        borderRadius: 4,
        boxShadow: "0 4px 22px #2193b0",
        fontWeight: "bold",
        fontSize: 22
      }}>
        {message}
      </Box>
    </Fade>
  );
}