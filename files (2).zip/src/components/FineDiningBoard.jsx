import React, { useState } from "react";
import { Grid, Paper, Typography, Box, Fade, Chip, Button, Divider } from "@mui/material";
import FineDiningBanner from "./banners/FineDiningBanner";
import { useAgenticContext } from "../agentic/AgenticContext";

// Mock Data
const tables = [
  {
    id: 1,
    guest: "Table 10",
    courses: [
      { name: "Appetizer", status: "hold", eta: 6, allergy: "", pairing: "Chardonnay" },
      { name: "Main", status: "fire", eta: 16, allergy: "shellfish", pairing: "Pinot Noir" },
      { name: "Dessert", status: "hold", eta: 30, allergy: "", pairing: "Sauternes" }
    ],
    platingChecklist: { garnish: false, sauce: false, temp: false },
    vip: true
  },
  {
    id: 2,
    guest: "Table 4",
    courses: [
      { name: "Appetizer", status: "ready", eta: 0, allergy: "", pairing: "Champagne" },
      { name: "Main", status: "hold", eta: 18, allergy: "", pairing: "Cabernet" }
    ],
    platingChecklist: { garnish: false, sauce: false, temp: false },
    vip: false
  }
];

export default function FineDiningBoard({ analytics }) {
  const [quietMode, setQuietMode] = useState(true);
  const [checklists, setChecklists] = useState(() =>
    tables.reduce((obj, t) => ({ ...obj, [t.id]: { ...t.platingChecklist } }), {})
  );
  const { agenticState } = useAgenticContext();

  // Plating checklist handler
  const toggleChecklist = (tableId, field) => {
    setChecklists({
      ...checklists,
      [tableId]: { ...checklists[tableId], [field]: !checklists[tableId][field] }
    });
  };

  // Chef pass verify handler (VIP/allergen)
  const handleChefPass = (tableId) => {
    alert("Chef Pass Verified for Table " + tableId);
  };

  // Double acknowledgment for allergen
  const handleDoubleAck = (tableId, courseIdx) => {
    alert("Double acknowledgment for allergen at Table " + tableId + " Course " + courseIdx);
  };

  return (
    <Box sx={{
      background: quietMode ? "#f7f6f2" : "#fff",
      minHeight: "100vh",
      pb: 8,
      filter: quietMode ? "brightness(0.98)" : "none"
    }}>
      <Grid container spacing={2} sx={{ maxWidth: 1200, margin: "0 auto", pt: 2 }}>
        <Grid item xs={12}>
          <FineDiningBanner analytics={analytics} />
        </Grid>
        {tables.map((table, idx) => (
          <Grid item xs={12} md={6} key={table.id}>
            <Fade in timeout={600 + idx * 120}>
              <Paper
                elevation={quietMode ? 2 : 8}
                sx={{
                  p: 3,
                  mb: 2,
                  borderRadius: 4,
                  background: quietMode ? "#edeadf" : "#fff",
                  boxShadow: quietMode ? "0 2px 4px #ddd" : "0 8px 32px #fcb69f",
                  color: "#222",
                  position: "relative"
                }}
              >
                <Typography variant="h6" fontWeight="bold">{table.guest} {table.vip && <Chip label="VIP" color="primary" size="small" />}</Typography>
                {/* Coursing Timeline Ribbon */}
                <Box sx={{ mt: 2, mb: 1, display: "flex", gap: 2 }}>
                  {table.courses.map((course, cidx) => (
                    <Box key={course.name} sx={{ flex: 1, textAlign: "center", position: "relative" }}>
                      <Chip
                        label={course.name}
                        color={course.status === "fire" ? "success" : "default"}
                        sx={{
                          fontWeight: course.status === "fire" ? "bold" : "normal",
                          mb: 0.5,
                          fontSize: 16,
                          boxShadow: course.status === "fire" ? "0 0 10px #43e97b" : "none"
                        }}
                      />
                      <Typography variant="caption" sx={{ display: "block", mt: 0.5 }}>
                        {course.status === "fire" ? "Fire!" : "Hold"}
                      </Typography>
                      <Typography variant="body2">{course.eta} min</Typography>
                      {/* Allergy guardrails */}
                      {course.allergy && (
                        <Chip
                          label={"Allergy: " + course.allergy}
                          color="error"
                          sx={{
                            position: "absolute",
                            left: "50%",
                            transform: "translateX(-50%)",
                            top: 38,
                            fontWeight: "bold"
                          }}
                          onClick={() => handleDoubleAck(table.id, cidx)}
                        />
                      )}
                      {/* Sommelier prompts */}
                      <Chip
                        label={"Pair: " + course.pairing}
                        color="info"
                        variant="outlined"
                        sx={{ mt: 4, fontSize: 14 }}
                      />
                    </Box>
                  ))}
                </Box>
                <Divider sx={{ my: 2 }} />
                {/* Plating Checklist */}
                <Box sx={{ display: "flex", gap: 2, alignItems: "center", mb: 1 }}>
                  <Typography variant="subtitle2" fontWeight="bold">Plating:</Typography>
                  {["garnish", "sauce", "temp"].map(field => (
                    <Chip
                      key={field}
                      label={field.charAt(0).toUpperCase() + field.slice(1)}
                      color={checklists[table.id][field] ? "success" : "default"}
                      onClick={() => toggleChecklist(table.id, field)}
                      sx={{ fontWeight: "bold", fontSize: 15, cursor: "pointer" }}
                    />
                  ))}
                </Box>
                {/* Chef Pass Verify for VIP/allergen */}
                {(table.vip || table.courses.some(c => c.allergy)) && (
                  <Button variant="contained" color="secondary" onClick={() => handleChefPass(table.id)}>
                    Chef Pass Verify
                  </Button>
                )}
              </Paper>
            </Fade>
          </Grid>
        ))}
      </Grid>
      {/* Quiet Mode Toggle */}
      <Box sx={{ position: "fixed", top: 20, right: 20, zIndex: 2000 }}>
        <Button
          variant="contained"
          color="info"
          onClick={() => setQuietMode(!quietMode)}
        >
          {quietMode ? "Disable Quiet Mode" : "Enable Quiet Mode"}
        </Button>
      </Box>
    </Box>
  );
}