import React, { useContext } from "react";
import { AgenticContext } from "../agentic/AgenticContext";

export default function AgenticDashboard() {
  const { recommendations, alertBanner, anomalies, kpiAnalysis } = useContext(AgenticContext);

  return (
    <div style={{ padding: 24, background: "#fffbe6", borderRadius: 14 }}>
      {alertBanner && (
        <div style={{ color: "#d32f2f", fontWeight: "bold", marginBottom: 12 }}>
          {alertBanner}
        </div>
      )}
      <h2>AI Recommendations</h2>
      <ul>
        {recommendations.map((rec, i) => (
          <li key={i}>{rec}</li>
        ))}
      </ul>
      <h3>Detected Anomalies</h3>
      <ul>
        {anomalies.map((a, i) => (
          <li key={i} style={{ color: "#ff9800" }}>{a}</li>
        ))}
      </ul>
      <h3>KPI Analysis</h3>
      <pre>{JSON.stringify(kpiAnalysis, null, 2)}</pre>
    </div>
  );
}