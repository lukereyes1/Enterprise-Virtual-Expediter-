import React from "react";

const modes = [
  { key: "fastCasual", label: "Fast Casual" },
  { key: "fineDining", label: "Fine Dining" },
  { key: "chain", label: "Chain" },
  { key: "catering", label: "Catering" },
];

export default function ModeSwitcher({ mode, setMode }) {
  return (
    <div style={{ display: "flex", gap: "10px", marginBottom: "20px" }}>
      {modes.map(({ key, label }) => (
        <button
          key={key}
          style={{
            background: mode === key ? "#32CD32" : "#eee",
            color: "#333",
            borderRadius: 6,
            padding: "8px 16px",
            fontWeight: "bold",
            boxShadow: mode === key ? "0 0 8px #32CD32" : "none",
            border: "none",
            cursor: "pointer"
          }}
          onClick={() => setMode(key)}
        >
          {label}
        </button>
      ))}
    </div>
  );
}