import React, { useState } from "react";
import { Box, Button, Typography, Chip, Fade } from "@mui/material";
import { sendVoiceAudio } from "../api/agentic";

export default function VoiceCommandAgent({ userRole, onIntent }) {
  const [transcript, setTranscript] = useState("");
  const [intent, setIntent] = useState("");
  const [status, setStatus] = useState("");
  const [banner, setBanner] = useState("");

  async function handleAudioUpload(e) {
    setStatus("Processing...");
    const audioBuffer = await e.target.files[0].arrayBuffer();
    const result = await sendVoiceAudio(audioBuffer, userRole);
    setTranscript(result.transcript);
    setIntent(result.intent);
    setStatus("Done.");

    // Voice–Visual Twin banner
    setBanner(result.intent ? `Intent: ${result.intent}` : result.transcript);

    // Optionally trigger dashboard action
    if (onIntent) onIntent(result.intent, result.transcript);

    // Auto-dismiss banner after 3s
    setTimeout(() => setBanner(""), 3000);
  }

  return (
    <Box sx={{ p: 2, background: "#eaeaea", borderRadius: 2, mb: 2 }}>
      <Typography variant="h6" fontWeight="bold">Voice Command</Typography>
      <input type="file" accept="audio/*" onChange={handleAudioUpload} />
      <Typography>Status: {status}</Typography>
      <Typography>Transcript: {transcript}</Typography>
      <Typography>Intent: <b>{intent}</b></Typography>
      <Fade in={!!banner}>
        <Box sx={{
          position: "fixed", bottom: 40, left: "50%",
          transform: "translateX(-50%)",
          zIndex: 2500, background: "#2193b0", color: "#fff",
          px: 4, py: 2, borderRadius: 4, boxShadow: "0 4px 22px #2193b0",
          fontWeight: "bold", fontSize: 22
        }}>
          {banner}
        </Box>
      </Fade>
    </Box>
  );
}