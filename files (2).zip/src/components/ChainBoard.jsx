import React, { useState } from "react";
import { Grid, Paper, Typography, Box, Fade, Chip, Button, Divider, Avatar } from "@mui/material";
import ChainBanner from "./banners/ChainBanner";
import { useAgenticContext } from "../agentic/AgenticContext";

// Mock Brand Kits
const brandKits = {
  "TacoFast": { primary: "#f44336", logo: "/logos/tacofast.png" },
  "BurgerMax": { primary: "#2196f3", logo: "/logos/burgermax.png" },
  "SaladPlus": { primary: "#4caf50", logo: "/logos/saladplus.png" }
};

// Sample device/region
const storeRegion = "NorthEast";
const storeBrand = "TacoFast";

// Mock Data
const initialTiles = [
  {
    id: 1, item: "Chicken Burrito", variant: "A", kpi: 97, tenure: "new", sop: "Heat tortilla, add protein, wrap tight",
    promo: "BOGO Today!", promoDelta: "+2min", opsCheck: false
  },
  {
    id: 2, item: "Avocado Salad", variant: "B", kpi: 93, tenure: "veteran", sop: "Add greens, avocado, dressing, toss",
    promo: "", promoDelta: "", opsCheck: true
  }
];

const checklists = [
  { id: "open", label: "Open Fridge", photoRequired: true },
  { id: "close", label: "Sanitize Slicer", photoRequired: false }
];

export default function ChainBoard({ analytics, featureFlags }) {
  const [tiles, setTiles] = useState(initialTiles);
  const [showSOP, setShowSOP] = useState({}); // {tileId: bool}
  const [opsChecks, setOpsChecks] = useState({});
  const { agenticState } = useAgenticContext();

  // Brand Kit
  const brand = brandKits[storeBrand];

  // SOP Card toggle
  const handleToggleSOP = (id) => setShowSOP({ ...showSOP, [id]: !showSOP[id] });

  // Ops Compliance toggle
  const handleOpsCheck = (id) => setOpsChecks({ ...opsChecks, [id]: !opsChecks[id] });

  // Remote Kill-Switch (feature flag)
  if (featureFlags && !featureFlags[storeRegion]) {
    return (
      <Paper sx={{ m: 8, p: 6, textAlign: "center", borderRadius: 8, background: "#eee" }}>
        <Typography variant="h4" color="error">Store Features Disabled</Typography>
        <Typography variant="body1" sx={{ mt: 2 }}>Contact support to enable features for your region.</Typography>
      </Paper>
    );
  }

  return (
    <Box sx={{ background: "#eef6fb", minHeight: "100vh", pb: 8 }}>
      <Grid container spacing={2} sx={{ maxWidth: 1200, margin: "0 auto", pt: 2 }}>
        <Grid item xs={12}>
          <ChainBanner analytics={analytics} brand={brand} />
        </Grid>
        {/* Promo Injection Zones */}
        {tiles.map((tile, idx) => (
          <Grid item xs={12} sm={6} md={4} key={tile.id}>
            <Fade in timeout={500 + idx * 100}>
              <Paper
                elevation={8}
                sx={{
                  p: 2,
                  mb: 2,
                  borderRadius: 4,
                  background: brand.primary,
                  color: "#fff",
                  minHeight: 140,
                  position: "relative",
                  boxShadow: tile.kpi > 95
                    ? "0 8px 32px #4caf50"
                    : "0 2px 10px #eee"
                }}
              >
                <Box display="flex" alignItems="center" justifyContent="space-between">
                  <Box display="flex" alignItems="center">
                    <Avatar src={brand.logo} sx={{ mr: 2 }} alt={storeBrand} />
                    <Typography variant="h6" fontWeight="bold">{tile.item}</Typography>
                  </Box>
                  <Chip label={"Variant " + tile.variant} color="info" />
                </Box>
                <Typography variant="body1" sx={{ mt: 1 }}>
                  KPI: <b>{tile.kpi}%</b>
                </Typography>
                {tile.promo && (
                  <Chip label={tile.promo} color="warning" sx={{ mt: 1, fontWeight: "bold" }} />
                )}
                {tile.promoDelta && (
                  <Typography variant="caption" sx={{ color: "#ffd600", fontWeight: "bold", ml: 1 }}>
                    {tile.promoDelta}
                  </Typography>
                )}
                {/* Inline SOP Card */}
                <Box sx={{ mt: 2 }}>
                  <Button size="small" variant="contained" color="info" onClick={() => handleToggleSOP(tile.id)}>
                    SOP {showSOP[tile.id] ? "Hide" : "Show"}
                  </Button>
                  {showSOP[tile.id] && (
                    <Paper elevation={2} sx={{ mt: 1, p: 2, background: "#fff", color: "#333" }}>
                      <Typography variant="body2" fontWeight="bold">SOP:</Typography>
                      <Typography variant="body2">{tile.sop}</Typography>
                    </Paper>
                  )}
                </Box>
                {/* Ops Compliance Mode */}
                <Box sx={{ mt: 2 }}>
                  <Chip
                    label={tile.opsCheck ? "Ops Checked" : "Needs Ops"}
                    color={tile.opsCheck ? "success" : "error"}
                    onClick={() => handleOpsCheck(tile.id)}
                  />
                </Box>
                {/* A/B HUD */}
                <Box sx={{ position: "absolute", top: 8, right: 8 }}>
                  <Chip label={"A/B"} color="secondary" />
                </Box>
              </Paper>
            </Fade>
          </Grid>
        ))}
        {/* Ops Compliance Checklist */}
        <Grid item xs={12}>
          <Paper elevation={4} sx={{ p: 2, borderRadius: 4, background: "#fff" }}>
            <Typography variant="h6" fontWeight="bold">Ops Compliance Mode</Typography>
            <Box display="flex" gap={2} mt={1}>
              {checklists.map(check => (
                <Chip
                  key={check.id}
                  label={check.label + (check.photoRequired ? " (Photo)" : "")}
                  color={opsChecks[check.id] ? "success" : "default"}
                  onClick={() => handleOpsCheck(check.id)}
                />
              ))}
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
}