import React from "react";
import { Paper, Grid, Box, Typography, Slide } from "@mui/material";
import CelebrationIcon from "@mui/icons-material/Celebration";
import LocalDiningIcon from "@mui/icons-material/LocalDining";
import SavingsIcon from "@mui/icons-material/AttachMoney";

export default function FineDiningBanner({ analytics }) {
  return (
    <Slide direction="down" in timeout={700}>
      <Paper
        elevation={8}
        sx={{
          background: "linear-gradient(90deg,#ffecd2 0%,#fcb69f 100%)",
          mb: 3,
          p: 3,
          borderRadius: 5,
          boxShadow: "0 12px 36px rgba(252,182,159,0.16)",
        }}
      >
        <Grid container spacing={3} alignItems="center">
          <Grid item xs={12} md={4}>
            <Box display="flex" alignItems="center">
              <CelebrationIcon sx={{ fontSize: 52, color: "#fcb69f", mr: 2 }} />
              <Typography variant="h5" color="#222" fontWeight="bold">
                Guest Experience Score: {analytics.guestScore}/100
              </Typography>
            </Box>
            <Typography color="#222" mt={1}>
              {analytics.guestScore > 90
                ? "Exceptional! Keep delighting guests."
                : "Review flagged tables for feedback."}
            </Typography>
          </Grid>
          <Grid item xs={12} md={4}>
            <Box display="flex" alignItems="center">
              <LocalDiningIcon sx={{ fontSize: 52, color: "#fcb69f", mr: 2 }} />
              <Typography variant="h5" color="#222" fontWeight="bold">
                Courses On-Time: {analytics.coursesOnTime}%
              </Typography>
            </Box>
            <Typography color="#222" mt={1}>
              Multi-course timing optimization
            </Typography>
          </Grid>
          <Grid item xs={12} md={4}>
            <Box display="flex" alignItems="center">
              <SavingsIcon sx={{ fontSize: 52, color: "#fcb69f", mr: 2 }} />
              <Typography variant="h5" color="#222" fontWeight="bold">
                ${analytics.dollarsSaved}
              </Typography>
            </Box>
            <Typography color="#222" mt={1}>
              Saved from upsells, reduced waste
            </Typography>
          </Grid>
        </Grid>
      </Paper>
    </Slide>
  );
}