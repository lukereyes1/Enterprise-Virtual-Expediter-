import React from "react";
import { Paper, Grid, Box, Typography, Fade } from "@mui/material";
import SavingsIcon from "@mui/icons-material/AttachMoney";
import SpeedIcon from "@mui/icons-material/Speed";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";

export default function FastCasualBanner({ analytics }) {
  return (
    <Fade in timeout={600}>
      <Paper
        elevation={6}
        sx={{
          background: "linear-gradient(90deg,#43e97b 0%,#38f9d7 100%)",
          mb: 3,
          p: 3,
          borderRadius: 3,
          boxShadow: "0 8px 32px rgba(67,233,123,0.24)",
        }}
      >
        <Grid container spacing={3} alignItems="center">
          <Grid item xs={12} md={4}>
            <Box display="flex" alignItems="center">
              <SpeedIcon sx={{ fontSize: 52, color: "#fff", mr: 2 }} />
              <Typography variant="h5" color="#fff" fontWeight="bold">
                Avg. Cycle Time: {analytics.cycleTime} min
              </Typography>
            </Box>
            <Typography color="#fff" mt={1}>
              {analytics.cycleImprovement > 0
                ? `Improved by ${analytics.cycleImprovement}% this week!`
                : "Keep pushing for faster hand-offs!"}
            </Typography>
          </Grid>
          <Grid item xs={12} md={4}>
            <Box display="flex" alignItems="center">
              <SavingsIcon sx={{ fontSize: 52, color: "#fff", mr: 2 }} />
              <Typography variant="h5" color="#fff" fontWeight="bold">
                ${analytics.dollarsSaved}
              </Typography>
            </Box>
            <Typography color="#fff" mt={1}>
              Dollars saved from faster service and reduced errors
            </Typography>
          </Grid>
          <Grid item xs={12} md={4}>
            <Box display="flex" alignItems="center">
              <CheckCircleIcon sx={{ fontSize: 52, color: "#fff", mr: 2 }} />
              <Typography variant="h5" color="#fff" fontWeight="bold">
                {analytics.ackRate}%
              </Typography>
            </Box>
            <Typography color="#fff" mt={1}>
              Ticket Acknowledgment Rate (target: 95%+)
            </Typography>
          </Grid>
        </Grid>
      </Paper>
    </Fade>
  );
}