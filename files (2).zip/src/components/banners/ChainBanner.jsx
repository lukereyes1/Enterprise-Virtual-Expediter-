import React from "react";
import { Paper, Grid, Box, Typography, Grow } from "@mui/material";
import StoreIcon from "@mui/icons-material/Store";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import SavingsIcon from "@mui/icons-material/AttachMoney";

export default function ChainBanner({ analytics }) {
  return (
    <Grow in timeout={800}>
      <Paper
        elevation={4}
        sx={{
          background: "linear-gradient(90deg,#2193b0 0%,#6dd5ed 100%)",
          mb: 3,
          p: 3,
          borderRadius: 4,
          boxShadow: "0 8px 32px rgba(33,147,176,0.24)",
        }}
      >
        <Grid container spacing={3} alignItems="center">
          <Grid item xs={12} md={4}>
            <Box display="flex" alignItems="center">
              <StoreIcon sx={{ fontSize: 52, color: "#fff", mr: 2 }} />
              <Typography variant="h5" color="#fff" fontWeight="bold">
                Chainwide Score: {analytics.chainScore}
              </Typography>
            </Box>
            <Typography color="#fff" mt={1}>
              {analytics.locationsReporting} locations reporting
            </Typography>
          </Grid>
          <Grid item xs={12} md={4}>
            <Box display="flex" alignItems="center">
              <TrendingUpIcon sx={{ fontSize: 52, color: "#fff", mr: 2 }} />
              <Typography variant="h5" color="#fff" fontWeight="bold">
                ${analytics.dollarsSaved}
              </Typography>
            </Box>
            <Typography color="#fff" mt={1}>
              Dollars saved chainwide this month
            </Typography>
          </Grid>
          <Grid item xs={12} md={4}>
            <Box display="flex" alignItems="center">
              <TrendingUpIcon sx={{ fontSize: 52, color: "#fff", mr: 2 }} />
              <Typography variant="h5" color="#fff" fontWeight="bold">
                {analytics.trend}
              </Typography>
            </Box>
            <Typography color="#fff" mt={1}>
              {analytics.trendDescription}
            </Typography>
          </Grid>
        </Grid>
      </Paper>
    </Grow>
  );
}