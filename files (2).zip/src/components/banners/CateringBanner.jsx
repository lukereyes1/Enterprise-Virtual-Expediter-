import React from "react";
import { Paper, Grid, Box, Typography, Zoom } from "@mui/material";
import EventIcon from "@mui/icons-material/Event";
import DeliveryDiningIcon from "@mui/icons-material/DeliveryDining";
import SavingsIcon from "@mui/icons-material/AttachMoney";

export default function CateringBanner({ analytics }) {
  return (
    <Zoom in timeout={900}>
      <Paper
        elevation={7}
        sx={{
          background: "linear-gradient(90deg,#ee9ca7 0%,#ffdde1 100%)",
          mb: 3,
          p: 3,
          borderRadius: 6,
          boxShadow: "0 12px 36px rgba(238,156,167,0.18)",
        }}
      >
        <Grid container spacing={3} alignItems="center">
          <Grid item xs={12} md={4}>
            <Box display="flex" alignItems="center">
              <EventIcon sx={{ fontSize: 52, color: "#ee9ca7", mr: 2 }} />
              <Typography variant="h5" color="#222" fontWeight="bold">
                Events Served: {analytics.eventsServed}
              </Typography>
            </Box>
            <Typography color="#222" mt={1}>
              {analytics.activeDeliveries} active deliveries today
            </Typography>
          </Grid>
          <Grid item xs={12} md={4}>
            <Box display="flex" alignItems="center">
              <DeliveryDiningIcon sx={{ fontSize: 52, color: "#ee9ca7", mr: 2 }} />
              <Typography variant="h5" color="#222" fontWeight="bold">
                On-Time Delivery: {analytics.onTimePct}%
              </Typography>
            </Box>
            <Typography color="#222" mt={1}>
              {analytics.deliveryRecommendation}
            </Typography>
          </Grid>
          <Grid item xs={12} md={4}>
            <Box display="flex" alignItems="center">
              <SavingsIcon sx={{ fontSize: 52, color: "#ee9ca7", mr: 2 }} />
              <Typography variant="h5" color="#222" fontWeight="bold">
                ${analytics.dollarsSaved}
              </Typography>
            </Box>
            <Typography color="#222" mt={1}>
              Saved from delivery optimization
            </Typography>
          </Grid>
        </Grid>
      </Paper>
    </Zoom>
  );
}