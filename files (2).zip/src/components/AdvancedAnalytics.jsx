import React, { useContext } from "react";
import { AgenticContext } from "../agentic/AgenticContext";

export default function AdvancedAnalytics() {
  const { kpiAnalysis } = useContext(AgenticContext);

  return (
    <div style={{ padding: 24, background: "#f2f2fa", borderRadius: 14 }}>
      <h2>Agentic Advanced Analytics</h2>
      <h3>Trend Predictions</h3>
      <ul>
        {(kpiAnalysis.trends || []).map((trend, idx) => (
          <li key={idx}>{trend}</li>
        ))}
      </ul>
      <h3>Cost-Saving Opportunities</h3>
      <ul>
        {(kpiAnalysis.costSaves || []).map((save, idx) => (
          <li key={idx} style={{ color: "#32CD32" }}>{save}</li>
        ))}
      </ul>
      <h3>Staffing & Delivery Recommendations</h3>
      <ul>
        {(kpiAnalysis.staffing || []).map((rec, idx) => (
          <li key={idx}>{rec}</li>
        ))}
      </ul>
    </div>
  );
}