import React, { useState } from "react";
import { Grid, Paper, Typography, Box, Fade, Chip, Button, Divider } from "@mui/material";
import CateringBanner from "./banners/CateringBanner";
import RiskBar from "./RiskBar";
import TrainingOverlay from "./TrainingOverlay";
import { useAgenticContext } from "../agentic/AgenticContext";
import { useAccessibility } from "../hooks/useAccessibility";
import { useMultilingual } from "../hooks/useMultilingual";

// Mock Data
const waves = [
  { label: "Wave 1", staff: ["Sam", "Jia"], timer: 38 },
  { label: "Wave 2", staff: ["Luis"], timer: 18 },
  { label: "Wave 3", staff: ["Kira"], timer: 0 }
];

const eventTimeline = [
  { phase: "Prep", time: "06:00" },
  { phase: "Pack", time: "07:30" },
  { phase: "Dispatch", time: "09:00" },
  { phase: "Service", time: "10:00" }
];

const drivers = [
  { name: "Tom", eta: 22, routeOrder: 1, readyNext: true },
  { name: "Mel", eta: 10, routeOrder: 2, readyNext: false }
];

const loadOutManifest = [
  { item: "Pan A", scanned: true, coldChain: "06:55" },
  { item: "Rack B", scanned: false, coldChain: "" }
];

const scaling = [
  { item: "Chicken Pan", base: 20, guestCount: 60, scaled: 60 },
  { item: "Salad Tray", base: 10, guestCount: 60, scaled: 30 }
];

const labels = [
  { item: "Chicken Pan", allergen: "soy", time: "06:55" },
  { item: "Salad Tray", allergen: "", time: "07:02" }
];

export default function CateringBoard({ analytics, riskData, trainingData }) {
  const { agenticState } = useAgenticContext();
  const { highContrast, setHighContrast } = useAccessibility();
  const { language, setLanguage, t } = useMultilingual();
  const [activeWave, setActiveWave] = useState(0);

  // Accessibility/Multilingual
  const labelColor = (allergen) => allergen ? "error" : "success";

  // One-Gesture Actions (stubbed)
  const handleGesture = (action, idx) => {
    // e.g. long-press, swipe-right, swipe-down, etc
    alert(`Gesture: ${action} on #${idx}`);
  };

  return (
    <Box sx={{ background: highContrast ? "#222" : "#f8fafc", minHeight: "100vh", pb: 8 }}>
      <Grid container spacing={2} sx={{ maxWidth: 1200, margin: "0 auto", pt: 2 }}>
        <Grid item xs={12}>
          <CateringBanner analytics={analytics} />
        </Grid>
        {/* Batch Wave Boards */}
        <Grid item xs={12}>
          <Paper elevation={8} sx={{ p: 3, borderRadius: 4, mb: 2, background: "#ffe0e9" }}>
            <Typography variant="h6" fontWeight="bold">Batch Waves</Typography>
            <Box display="flex" gap={2} mt={2}>
              {waves.map((wave, idx) => (
                <Button
                  key={wave.label}
                  variant={activeWave === idx ? "contained" : "outlined"}
                  color="secondary"
                  sx={{
                    fontWeight: "bold",
                    fontSize: 16,
                    borderRadius: 2,
                    px: 3,
                    py: 2,
                    boxShadow: activeWave === idx ? "0 8px 22px #ee9ca7" : "none"
                  }}
                  onClick={() => setActiveWave(idx)}
                  onContextMenu={(e) => { e.preventDefault(); handleGesture("hold", idx); }}
                  onTouchEnd={() => handleGesture("ready", idx)}
                >
                  {wave.label} <Chip label={wave.timer + "min"} color="info" sx={{ ml: 2 }} />
                  <Chip label={"Staff: " + wave.staff.join(", ")} color="primary" sx={{ ml: 2 }} />
                </Button>
              ))}
            </Box>
          </Paper>
        </Grid>
        {/* Portion/Yield Scaler */}
        <Grid item xs={12} md={6}>
          <Paper elevation={4} sx={{ p: 2, borderRadius: 4, background: "#fff" }}>
            <Typography variant="h6" fontWeight="bold">Portion/Yield Scaler</Typography>
            <Box mt={2}>
              {scaling.map((item, idx) => (
                <Chip
                  key={item.item}
                  label={`${item.item}: ${item.base} → ${item.scaled} (${t("guests")}: ${item.guestCount})`}
                  color="info"
                  sx={{ fontWeight: "bold", fontSize: 16, mb: 1, mr: 1 }}
                />
              ))}
            </Box>
          </Paper>
        </Grid>
        {/* Load-Out Manifest */}
        <Grid item xs={12} md={6}>
          <Paper elevation={4} sx={{ p: 2, borderRadius: 4, background: "#fff" }}>
            <Typography variant="h6" fontWeight="bold">Load-Out Manifest</Typography>
            <Box mt={2}>
              {loadOutManifest.map((item, idx) => (
                <Chip
                  key={item.item}
                  label={`${item.item} ${item.scanned ? "✓" : "✗"} ${item.coldChain && `(ColdChain: ${item.coldChain})`}`}
                  color={item.scanned ? "success" : "error"}
                  sx={{ fontWeight: "bold", fontSize: 16, mb: 1, mr: 1 }}
                  onClick={() => handleGesture("scan", idx)}
                />
              ))}
            </Box>
          </Paper>
        </Grid>
        {/* Label Studio */}
        <Grid item xs={12} md={6}>
          <Paper elevation={4} sx={{ p: 2, borderRadius: 4, background: "#fff" }}>
            <Typography variant="h6" fontWeight="bold">Label Studio</Typography>
            <Box mt={2}>
              {labels.map((item, idx) => (
                <Chip
                  key={item.item}
                  label={`${item.item}${item.allergen ? " (" + t("Allergen") + ": " + item.allergen + ")" : ""} ${item.time}`}
                  color={labelColor(item.allergen)}
                  sx={{ fontWeight: "bold", fontSize: 16, mb: 1, mr: 1 }}
                  onClick={() => handleGesture("label", idx)}
                />
              ))}
            </Box>
          </Paper>
        </Grid>
        {/* Driver Route Board */}
        <Grid item xs={12} md={6}>
          <Paper elevation={4} sx={{ p: 2, borderRadius: 4, background: "#fff" }}>
            <Typography variant="h6" fontWeight="bold">Driver Route Board</Typography>
            <Box mt={2}>
              {drivers.map((driver, idx) => (
                <Chip
                  key={driver.name}
                  label={`${driver.name} ETA: ${driver.eta}min Route: ${driver.routeOrder}${driver.readyNext ? " (Ready Next)" : ""}`}
                  color={driver.readyNext ? "success" : "info"}
                  sx={{ fontWeight: "bold", fontSize: 16, mb: 1, mr: 1 }}
                  onClick={() => handleGesture("route", idx)}
                />
              ))}
            </Box>
          </Paper>
        </Grid>
        {/* Event Timeline View */}
        <Grid item xs={12}>
          <Paper elevation={4} sx={{ p: 2, borderRadius: 4, background: "#fff" }}>
            <Typography variant="h6" fontWeight="bold">Event Timeline</Typography>
            <Box display="flex" gap={2} mt={2}>
              {eventTimeline.map((evt, idx) => (
                <Chip
                  key={evt.phase}
                  label={`${evt.phase} - ${evt.time}`}
                  color="secondary"
                  sx={{ fontWeight: "bold", fontSize: 16, mb: 1, mr: 1 }}
                  onClick={() => handleGesture("timeline", idx)}
                />
              ))}
            </Box>
          </Paper>
        </Grid>
        {/* Risk Bar */}
        <Grid item xs={12}>
          <RiskBar riskData={riskData} />
        </Grid>
        {/* Training Overlay */}
        <TrainingOverlay trainingData={trainingData} />
      </Grid>
      {/* Accessibility & Multilingual Controls */}
      <Box sx={{ position: "fixed", top: 20, right: 20, zIndex: 2000 }}>
        <Button variant="contained" color={highContrast ? "info" : "secondary"} onClick={() => setHighContrast(!highContrast)}>
          {highContrast ? t("Normal Contrast") : t("High Contrast")}
        </Button>
        <Button variant="outlined" color="primary" onClick={() => setLanguage(language === "en" ? "es" : "en")} sx={{ ml: 2 }}>
          {t("Language")}: {language === "en" ? "English" : "Español"}
        </Button>
      </Box>
      {/* Voice–Visual Twin Banner (example) */}
      {agenticState.alertBanner && (
        <Fade in timeout={300}>
          <Box sx={{
            position: "fixed",
            bottom: 30,
            left: "50%",
            transform: "translateX(-50%)",
            zIndex: 2500,
            background: "#ee9ca7",
            color: "#fff",
            px: 4, py: 2,
            borderRadius: 4,
            boxShadow: "0 4px 22px #ee9ca7",
            fontWeight: "bold",
            fontSize: 22
          }}>
            {agenticState.alertBanner}
          </Box>
        </Fade>
      )}
    </Box>
  );
}