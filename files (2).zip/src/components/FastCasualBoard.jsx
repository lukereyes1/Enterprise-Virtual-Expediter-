import React, { useState, useEffect } from "react";
import { Grid, Paper, Typography, Box, Fade, Chip, Button } from "@mui/material";
import FastCasualBanner from "./banners/FastCasualBanner";
import PrepHeatmap from "./PrepHeatmap";
import PickupShelfTracker from "./PickupShelfTracker";
import CourierStrip from "./banners/CourierStrip";
import RunnerAlertBanner from "./banners/RunnerAlertBanner";
import RiskBar from "./RiskBar";
import TrainingOverlay from "./TrainingOverlay";
import { useAgenticContext } from "../agentic/AgenticContext";
import { useAccessibility } from "../hooks/useAccessibility";
import { useMultilingual } from "../hooks/useMultilingual";

const initialTickets = [
  { id: 1, items: ["Burger"], station: "Grill", status: "new", eta: 11, allergy: "nuts", batched: false, shelfSlot: "A2" },
  { id: 2, items: ["Fries"], station: "Fry", status: "pending_ack", eta: 7, batched: true, shelfSlot: "A3" },
  { id: 3, items: ["Salad"], station: "Salad", status: "in_prep", eta: 3, batched: true, shelfSlot: "B1" },
  { id: 4, items: ["Burger"], station: "Grill", status: "ready", eta: 0, batched: true, shelfSlot: "A1" },
];

export default function FastCasualBoard({ analytics, runnerStatus, courierStatus, prepData, shelfMap, riskData, trainingData }) {
  const [tickets, setTickets] = useState(initialTickets);
  const { agenticState } = useAgenticContext();
  const { highContrast, setHighContrast } = useAccessibility();
  const { language, setLanguage, t } = useMultilingual();

  const handleAcknowledge = (id) => {
    setTickets(tickets.map(t => t.id === id ? { ...t, status: "in_prep" } : t));
  };

  const handleReady = (id) => {
    setTickets(tickets.map(t => t.id === id ? { ...t, status: "ready" } : t));
  };
  const handleEscalate = (id) => {
    setTickets(tickets.map(t => t.id === id ? { ...t, status: "escalated" } : t));
  };

  useEffect(() => {
    // Accessibility and multilingual logic here.
  }, [language]);

  return (
    <Box sx={{ background: highContrast ? "#222" : "#f5f7fa", minHeight: "100vh", pb: 8 }}>
      <Grid container spacing={2} sx={{ maxWidth: 1200, margin: "0 auto", pt: 2 }}>
        <Grid item xs={12}>
          <FastCasualBanner analytics={analytics} />
        </Grid>
        <Grid item xs={12}>
          <PrepHeatmap prepData={prepData} />
        </Grid>
        {tickets.map(ticket => (
          <Grid item xs={12} sm={6} md={4} key={ticket.id}>
            <Fade in timeout={500}>
              <Paper
                elevation={8}
                sx={{
                  p: 2,
                  mb: 2,
                  borderRadius: 4,
                  background: ticket.batched ? "linear-gradient(90deg,#43e97b 0%,#38f9d7 100%)" : "#fff",
                  boxShadow: ticket.status === "ready" ? "0 8px 32px #32CD32" : "0 2px 10px #eee",
                  color: highContrast ? "#fff" : "#333",
                  minHeight: 140,
                  position: "relative",
                  cursor: "pointer",
                  transition: "box-shadow 0.2s",
                  "&:hover": { boxShadow: "0 12px 36px #2196F3" }
                }}
                aria-label={t("Ticket for") + " " + ticket.items.join(", ")}
                tabIndex={0}
                onClick={() => handleAcknowledge(ticket.id)}
                onContextMenu={(e) => { e.preventDefault(); handleEscalate(ticket.id); }}
                onTouchEnd={() => handleReady(ticket.id)}
              >
                <Box display="flex" alignItems="center" justifyContent="space-between">
                  <Typography variant="h6" fontWeight="bold">{ticket.items.join(", ")}</Typography>
                  {ticket.allergy && <Chip label={t("Allergy") + ": " + ticket.allergy} color="error" />}
                </Box>
                <Typography variant="body1">{t("Station")}: {ticket.station} | {t("ETA")}: <b>{ticket.eta} min</b></Typography>
                {ticket.batched && <Chip label={t("Batch Grouped")} color="primary" sx={{ mt: 1 }} />}
                <Box sx={{ position: "absolute", bottom: 8, right: 8 }}>
                  <Chip label={ticket.shelfSlot} color="info" />
                </Box>
                <Box sx={{ position: "absolute", bottom: 8, left: 8 }}>
                  <Chip label={t("Training Score") + ": " + (trainingData[ticket.station] || 0)} color="secondary" />
                </Box>
              </Paper>
            </Fade>
          </Grid>
        ))}
        <Grid item xs={12} md={6}>
          <PickupShelfTracker shelfMap={shelfMap} tickets={tickets} />
        </Grid>
        <Grid item xs={12} md={6}>
          <RunnerAlertBanner runnerStatus={runnerStatus} />
          <CourierStrip courierStatus={courierStatus} />
        </Grid>
        <Grid item xs={12}>
          <RiskBar riskData={riskData} />
        </Grid>
        <TrainingOverlay trainingData={trainingData} />
      </Grid>
      <Box sx={{ position: "fixed", top: 20, right: 20, zIndex: 2000 }}>
        <Button variant="contained" color={highContrast ? "info" : "secondary"} onClick={() => setHighContrast(!highContrast)}>
          {highContrast ? t("Normal Contrast") : t("High Contrast")}
        </Button>
        <Button variant="outlined" color="primary" onClick={() => setLanguage(language === "en" ? "es" : "en")} sx={{ ml: 2 }}>
          {t("Language")}: {language === "en" ? "English" : "Español"}
        </Button>
      </Box>
    </Box>
  );
}