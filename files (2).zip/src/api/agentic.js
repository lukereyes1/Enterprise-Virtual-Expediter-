export async function fetchAgenticDashboard(userRole, location, kpiData) {
  const res = await fetch("/api/agentic/dashboard", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userRole, location, kpiData }),
  });
  return await res.json();
}

export async function sendVoiceAudio(audioBuffer, userRole) {
  const res = await fetch("/api/agentic/voice", {
    method: "POST",
    headers: { "Content-Type": "application/octet-stream", "x-user-role": userRole },
    body: audioBuffer,
  });
  return await res.json();
}