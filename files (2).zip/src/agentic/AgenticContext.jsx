import React, { createContext, useState, useEffect } from "react";
import { fetchAgenticDashboard } from "../api/agentic";

export const AgenticContext = createContext();

export function AgenticProvider({ children, userRole, location, kpiData }) {
  const [agenticState, setAgenticState] = useState({
    recommendations: [],
    alertBanner: "",
    anomalies: [],
    kpiAnalysis: {}
  });

  useEffect(() => {
    async function updateAgentic() {
      const data = await fetchAgenticDashboard(userRole, location, kpiData);
      setAgenticState(data);
    }
    updateAgentic();
    const interval = setInterval(updateAgentic, 30000);
    return () => clearInterval(interval);
  }, [userRole, location, kpiData]);

  return (
    <AgenticContext.Provider value={agenticState}>
      {children}
    </AgenticContext.Provider>
  );
}